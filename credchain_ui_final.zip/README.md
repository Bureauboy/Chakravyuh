﻿# CredChain UI Final
1. cd credchain-ui-final
2. npm install
3. npm run dev
4. Open http://localhost:5173
