﻿# CredChain UI (Max)

This is a demo React + Vite UI for the CredChain project.

Features:
- MetaMask connect (issue / verify flows need private key or server for issuing)
- Compute canonical VC hash via issuer API
- Verify on-chain (reads contract directly from browser)

Follow RUN_INSTRUCTIONS.txt for local startup steps.

