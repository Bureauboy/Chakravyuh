﻿import React from 'react'
import Issuer from './pages/Issuer'
import Verifier from './pages/Verifier'
import Wallet from './pages/Wallet'
import Header from './ui/Header'
import { ConfigProvider } from './utils/config'

export default function App(){
  const [page, setPage] = React.useState('issuer')
  return (
    <ConfigProvider>
      <div className='container'>
        <Header onNav={setPage} />
        <main>
          {page === 'issuer' && <Issuer />}
          {page === 'verifier' && <Verifier />}
          {page === 'wallet' && <Wallet />}
        </main>
      </div>
    </ConfigProvider>
  )
}

