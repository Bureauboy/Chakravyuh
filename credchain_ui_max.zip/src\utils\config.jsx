﻿import React from 'react'
const defaultConfig = {
  rpc: 'http://127.0.0.1:8545',
  issuerApi: 'http://localhost:4001',
  registryAddress: '0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512',
  issuerPrivateKey: '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80'
}
const ConfigContext = React.createContext(defaultConfig)
export const ConfigProvider = ({children})=> <ConfigContext.Provider value={defaultConfig}>{children}</ConfigContext.Provider>
export const useConfig = ()=> React.useContext(ConfigContext)
export const ConfigConsumer = ConfigContext.Consumer
export const useConfigSync = ()=> defaultConfig
export const Config = defaultConfig

