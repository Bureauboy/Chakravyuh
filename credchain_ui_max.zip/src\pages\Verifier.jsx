﻿import React from 'react'
import axios from 'axios'
import { useConfig } from '../utils/config'
import { ethers } from 'ethers'
import abiJson from '../abi/CredentialRegistry.json'

export default function Verifier(){
  const cfg = useConfig()
  const [fileText, setFileText] = React.useState('')
  const [result, setResult] = React.useState('')
  const [vcHash, setVcHash] = React.useState('')
  const [provider, setProvider] = React.useState(null)

  async function onFile(e){
    const f = e.target.files[0]; if(!f) return;
    const txt = await f.text(); setFileText(txt);
  }

  async function computeAndPrepare(){
    try{
      setResult('Computing...')
      const resp = await axios.post(cfg.issuerApi + '/api/compute', { vc: JSON.parse(fileText) })
      setVcHash(resp.data.vcHash)
      setResult('Computed hash: ' + resp.data.vcHash + '\\nYou can now run on-chain verify in-browser (connect MetaMask) or run the verify script.')
    }catch(e){ setResult('Error: '+(e.response?.data?.error||e.message)) }
  }

  async function connectWallet(){
    if(window.ethereum){
      const p = new ethers.BrowserProvider(window.ethereum)
      await p.send('eth_requestAccounts', [])
      setProvider(p)
      setResult('Wallet connected')
    }else setResult('MetaMask not found')
  }

  async function verifyOnChain(){
    if(!provider){ setResult('Connect wallet first'); return; }
    try{
      const contract = new ethers.Contract(cfg.registryAddress, abiJson.abi, provider)
      const parsed = JSON.parse(fileText)
      const student = parsed.credentialSubject.id
      const count = await contract.getCount(student)
      let found = false
      for(let i=0;i<Number(count);i++){
        const cred = await contract.getCred(student, i)
        if(cred[1].toLowerCase() === vcHash.toLowerCase()){
          setResult('MATCH FOUND at index '+i+' | issuer: '+cred[0]+' | cid: '+cred[2]+' | issuedAt: '+cred[3]+' | revoked: '+cred[4])
          found = true
          break
        }
      }
      if(!found) setResult('No match found on-chain')
    }catch(e){ setResult('Error: '+e.message) }
  }

  return (
    <div>
      <div className='card'>
        <h3>Verifier — Upload VC JSON</h3>
        <input type='file' accept='.json' onChange={onFile} />
        <div className='row' style={{marginTop:8}}>
          <button className='connect' onClick={computeAndPrepare}>Compute Hash</button>
          <button onClick={connectWallet}>Connect MetaMask</button>
          <button className='connect' onClick={verifyOnChain}>Verify On-chain (in-browser)</button>
        </div>
        <p className='small'>VC Hash: {vcHash}</p>
        <pre>{result}</pre>
      </div>
    </div>
  )
}
