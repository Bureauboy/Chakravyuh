﻿import React from 'react'
import { useConfig } from '../utils/config'
import { ethers } from 'ethers'
import abiJson from '../abi/CredentialRegistry.json'

export default function Wallet(){
  const cfg = useConfig()
  const [address, setAddress] = React.useState('')
  const [creds, setCreds] = React.useState([])
  const [provider, setProvider] = React.useState(null)

  async function connect(){
    if(window.ethereum){
      const p = new ethers.BrowserProvider(window.ethereum)
      await p.send('eth_requestAccounts', [])
      setProvider(p)
      const signer = await p.getSigner()
      const a = await signer.getAddress()
      setAddress(a)
    }
  }

  async function loadCreds(){
    if(!provider){ alert('connect'); return; }
    const contract = new ethers.Contract(cfg.registryAddress, abiJson.abi, provider)
    const count = await contract.getCount(address)
    const items = []
    for(let i=0;i<Number(count);i++){
      const c = await contract.getCred(address, i)
      items.push(c)
    }
    setCreds(items)
  }

  return (
    <div>
      <div className='card'>
        <h3>Wallet (Demo)</h3>
        <div className='row'>
          <button className='connect' onClick={connect}>Connect MetaMask</button>
          <button onClick={loadCreds}>Load Credentials</button>
        </div>
        <p className='small'>Connected: {address}</p>
        <div>
          {creds.map((c,idx)=>( 
            <div key={idx} className='card' style={{marginTop:8}}>
              <div><b>Issuer:</b> {c[0]}</div>
              <div><b>Hash:</b> {c[1]}</div>
              <div><b>CID:</b> {c[2]}</div>
              <div><b>IssuedAt:</b> {c[3].toString()}</div>
              <div><b>Revoked:</b> {c[4].toString()}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
