﻿import React from 'react'
import axios from 'axios'
import { useConfig } from '../utils/config'

export default function Issuer(){
  const cfg = useConfig()
  const [vcText, setVcText] = React.useState('')
  const [canonical, setCanonical] = React.useState('')
  const [vcHash, setVcHash] = React.useState('')
  const [status, setStatus] = React.useState('')

  async function computeHash(){
    try{
      setStatus('Computing...')
      const resp = await axios.post(cfg.issuerApi + '/api/compute', { vc: JSON.parse(vcText) })
      setCanonical(JSON.stringify(resp.data.canonical, null, 2))
      setVcHash(resp.data.vcHash)
      setStatus('Computed')
    }catch(e){ setStatus('Error: '+(e.response?.data?.error||e.message)) }
  }

  function issueCommand(){
    const parsed = JSON.parse(vcText || '{}')
    const student = parsed?.credentialSubject?.id || '<student address>'
    const cmd = 
ode scripts\\\\issue.js     none 
    return cmd
  }

  function loadSample(){ setVcText(JSON.stringify({\"@context\":[\"https://www.w3.org/ns/credentials/v2\"],\"type\":[\"VerifiableCredential\",\"DegreeCredential\"],\"issuer\":\"did:web:university.example\",\"issuanceDate\":\"2024-01-01T00:00:00Z\",\"credentialSubject\":{\"id\":\"0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266\",\"givenName\":\"Alice\",\"familyName\":\"Johnson\",\"degree\":{\"name\":\"Bachelor of Science\",\"major\":\"Computer Science\",\"dateAwarded\":\"2024-06-01\"},\"gpa\":3.9}})) }

  return (
    <div>
      <div className='card'>
        <h3>Issuer — Upload VC JSON</h3>
        <textarea value={vcText} onChange={e=>setVcText(e.target.value)} placeholder='Paste VC JSON here' />
        <div className='row' style={{marginTop:10}}>
          <button className='connect' onClick={computeHash}>Compute Hash</button>
          <button className='connect' onClick={()=>setStatus(issueCommand())}>Show Issue Command</button>
          <button onClick={loadSample}>Load sample</button>
        </div>
        <p className='small'>VC Hash: {vcHash}</p>
        <pre>{status}</pre>
      </div>

      <div className='card'>
        <h4>Canonical JSON</h4>
        <pre>{canonical}</pre>
      </div>
    </div>
  )
}
