﻿import React from 'react'
import { useConfig } from '../utils/config'

export default function Header({onNav}){
  const cfg = useConfig()
  return (
    <header>
      <div>
        <h1>CredChain — Demo (Max)</h1>
        <div className='small'>RPC: {cfg.rpc} • Registry: {cfg.registryAddress}</div>
      </div>
      <div>
        <nav>
          <button onClick={()=>onNav('issuer')}>Issuer</button>
          <button onClick={()=>onNav('verifier')}>Verifier</button>
          <button onClick={()=>onNav('wallet')}>Wallet</button>
        </nav>
      </div>
    </header>
  )
}
